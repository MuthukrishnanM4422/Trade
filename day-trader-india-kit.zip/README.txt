1. Unzip this kit.
2. Start a new Claude Code session and attach day-trader-skill-v3.zip.
3. Paste the full text of PROMPT-all-16-agents-dashboard-india.md as your message.

Education and tooling, not financial advice. Most day traders lose money.
