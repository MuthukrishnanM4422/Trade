# Complete prompt: all 16 agents (12 existing + Bull, Bear, Judge + Dashboard) for INR (NSE) trading

Paste everything below into a new Claude Code session. Attach `day-trader-skill-v3.zip` (the project built in the earlier session) first.

---

## ROLE AND GOAL

You are a senior Python engineer and risk-minded trading-tools developer. Extend the attached project (`day-trader-skill-v3.zip`, 12 Claude skills, also called agents, Python 3.8+, standard library only) so that:

1. All 12 existing agents stay in the project, keep working, and are part of one connected pipeline.
2. Four new agents are added: Bull, Bear, Judge and a Dashboard. The final system has 16 agents.
3. The whole pipeline works for Indian markets: NSE cash equities, Indian rupees (INR), Indian time (IST), Indian costs.
4. A web dashboard (HTML, CSS and JavaScript) shows which Indian-market trade to choose today and explains, step by step, how to follow it.
5. A plain-language guide explains which platform to use and how to set everything up.

I am a beginner trader in Chennai, India. I trade only in INR. My priority is losing as little money as possible. I accept that no code can make day trading low risk or predict the future. Be honest about that everywhere in the code, docs and replies.

Work style: direct and complete. Give me complete, production-ready files, not partial snippets. Run all tests. Zip the whole project and send it, plus the main new and changed files individually.

---

## THE 12 EXISTING AGENTS (keep all of them, adapt them for India)

Each is a folder `trader-<name>/` with `SKILL.md` and a Python script. Data is free and unofficial (Yahoo Finance chart JSON and similar), fetched one ticker at a time. None of them places an order except trader-broker, and only after a strict per-order "yes".

| # | Agent | What it does today (US version) | Reads / writes | India work needed |
| --- | --- | --- | --- | --- |
| 1 | **trader-scanner** (Chart Scanner) | Builds a list of US stocks from Nasdaq Trader directories. Pre-market scan of daily charts (20-day closing-high breakout, bull flag, reclaimed 20-day average, oversold, oversold bounce) and an intraday opening-range-breakout scan on 5-minute bars. | writes `trader/watchlist.json` | New India universe: Nifty 50 / Nifty 100 / Nifty 500 list with `.NS` tickers (a bundled editable list plus an option to load a file; NSE's site may block scripts, so do not depend on it). ORB scan with the 09:15 IST open. Liquidity filter in rupees of traded value. |
| 2 | **trader-news** (News Monitor) | Yahoo headlines per ticker, SEC EDGAR 8-K filings, distance from yesterday's close. Shows only what is new, newest first, tags items (earnings, analyst, deal, halt, regulatory, macro). | reads `watchlist.json`; writes news state | Replace SEC EDGAR with an India source. Use Yahoo headlines for `.NS` and a documented route for NSE/BSE corporate announcements (Claude web search, or a pasted announcement file). Times in IST. |
| 3 | **trader-entry** (Entry Timer) | Builds the opening range (first 15 minutes) from 1- or 5-minute bars and calls the entry on the first completed bar that closes above the range high (or a level you give), optional volume check. Long side only. | writes `trader/entry.json` | IST session (09:15 to 15:30), NSE holidays, 5-minute bar slots (75 a day), `.NS` tickers. |
| 4 | **trader-exit** (Exit Planner) | Sets the stop (opening-range midpoint, range low, a price, a percent, or ATR multiple) rounded down, and the target (2R, 1R, or a price). Refuses a stop above the entry, a target below it, or a stop too tight for the spread. Long only. | writes `trader/plan.json` | NSE tick size Rs 0.05 rounding, rupee formatting, IST flat-by time, NSE calendar. |
| 5 | **trader-timemachine** (Time Machine) | Replays 10,000 simulated sessions from the stock's own 5-minute bars (last 60 days) plus every past time the rule fired. Prints odds of target first, stop first, or neither, average R, the history, a verdict. v3 subtracts costs and runs an edge test (replays, history, and the most recent third of it). | reads `plan.json`; writes `trader/timemachine.json` | 75-bar IST sessions, India cost model (see Part 2), keep the after-cost edge test. |
| 6 | **trader-budget** (Budget Manager) | Sizes the position inside four limits (max loss per trade, position cap, max order, cash after buffer), says which limit decided, writes ONE bracket order. A stop too far for the max loss is a refusal, not a smaller order. | reads `plan.json`, config; writes `trader/orders.json` | Rupee limits and formatting, whole shares only, India config example, IST date. |
| 7 | **trader-risk** (Risk Manager) | Checks every order: stop required, loss at the stop within the limit, reward:risk minimum, daily/weekly limits, trades per day, entry window, blocked tickers, order size, position cap, cash buffer, margin, short, options, crypto, malformed or duplicate orders. v3 gates: data guard, edge after costs, weekly loss, losing-day streak, drawdown stop, live lock, `--status`. Exits are never blocked by the gates. | reads orders, portfolio, prices, state, guard, timemachine; writes `trader/risk.json` | Market profile (IST window, NSE holidays), rupee money format, India symbol rules, block derivative symbols (futures/options), India cost model in the realized profit calculation, new `require_judge` gate. |
| 8 | **trader-broker** (Order Executor) | Shows each order as a plain ticket, records the user's "yes" word for word, then Claude's own Allow once / Deny card asks again. Builds the sell ticket that closes the day trade by flat-by time, records fills (paper or live), logs each trade's max loss. Currently Alpaca and Interactive Brokers. | reads orders, risk; writes `trader/state/broker.json` | For India: manual order sheet (see Part 2) instead of an order tool, keep the strict one-order-at-a-time yes, fill logging (`ticket.py result` / `fill`), paper/live flag. Optional read-only Kite MCP connector. |
| 9 | **trader-alerts** (Price Alerts) | Turns the plan into three alerts (stop, target, flat-by), plus above/below levels, percent moves, times of day, and the opening bell. Fetches delayed quotes one ticker at a time, writes prices for sizing and risk. Each alert rings once. | writes `trader/prices.json`, alert state | NSE opening bell 09:15 IST, NSE calendar, `.NS` quotes (Stooq has no NSE; Yahoo only plus broker quote passed in). |
| 10 | **trader-analyst** (Earnings Analyst) | Reads reported numbers from SEC EDGAR (10-Q, 10-K, earnings 8-K): revenue, margins, net income, EPS, quarter by quarter and year over year; reads a pasted call transcript. | writes analysis | EDGAR is US only. For India accept pasted quarterly results (or a results file), compute the same year-over-year metrics, and feed upcoming results dates to the Bull/Bear agents as event risk. |
| 11 | **trader-pelosi** (Pelosi Tracker) | Reads House Clerk Periodic Transaction Reports (STOCK Act), alerts on new filings, turns PDFs into rows, flags trades in stocks you hold. | writes tracker state | US only and not useful for NSE trades. Keep it unchanged, mark it "US only, optional" in docs, and do not wire it into the India pipeline. Stretch goal: an India equivalent for bulk and block deals or insider (SEBI PIT) disclosures if a stable public source exists. |
| 12 | **trader-guard** (Data Guard, new in v3) | Checks the data right before an order: market open, last 1-minute bar fresh, bars sane, second source within tolerance. Records OK or BAD per symbol; trader-risk blocks entries without a fresh OK. | writes `trader/state/data_guard.json` | INR currency instead of USD, IST text, and `--second-price` / `--second-source` flags for a broker quote (Stooq does not cover NSE). |

Pipeline for one trade (India):
`scanner -> news -> entry -> guard -> exit -> timemachine -> BULL + BEAR -> JUDGE -> budget -> risk -> broker (manual order sheet)`, with alerts watching the stop, target and flat-by time, analyst feeding event dates to Bull/Bear, and the DASHBOARD reading every agent's output file and showing the result and the next step in one page.

Priority for the India adaptation: MUST (guard, bull, bear, judge, risk, budget, broker, exit, timemachine, entry, alerts), SHOULD (scanner, news), OPTIONAL (analyst, pelosi). Everything stays present in the project.

---

## PART 1: THE THREE DECISION AGENTS (Bull, Bear, Judge)

Build three new skills, each a folder with `SKILL.md` and a Python script: `trader-bull`, `trader-bear`, `trader-judge`.

Shared engine: put shared code in `trader-judge/evidence_lib.py`. Bull and Bear import it by sibling path and fail with a clear message if it is missing.

Input for all three: one candidate trade (symbol, side, entry, stop, target, date), read from `trader/plan.json` or from flags. Data: Yahoo Finance daily bars (1 year) and 5-minute bars (60 days), the Nifty 50 index (`^NSEI`) for market regime, recent headlines, plus the outputs of the existing agents where available (`entry.json`, `plan.json`, `timemachine.json`, `data_guard.json`, news state, analyst results dates).

### 13. Bull agent (`bull.py`): the case FOR the trade
Looks at the past, the present and the known future, and scores 0 to 100 from weighted evidence. Each evidence item has: id, claim, value, weight, points, source, kind (`past`, `present`, `future`, `research`). Examples:
- Past: trend (price above 20/50-day averages, 50 above 200), 3-month strength versus Nifty, base-rate replay of this stop/target geometry at this time of day over the last 60 sessions, net of India costs (expectancy in R, win rate, number of trades).
- Present: volume versus 20-day average, reward:risk of at least 1.5, price position in the 52-week range, market regime (Nifty above its 50-day average), liquidity (average daily traded value), entry-timer trigger confirmed.
- Future: scheduled positives only, supplied with `--event` flags (no guessing).
- Research: notes Claude finds on the web, passed with `--note`, `--note-points`, `--source`. Capped at plus or minus 10 points in total so research can never outvote the math.

### 14. Bear agent (`bear.py`): the case AGAINST the trade
Same format, written independently. It must not read `bull.json` before writing `bear.json`. When subagents are available, run Bull and Bear as separate subagents so neither sees the other's reasoning. Evidence includes: downtrend, weak relative strength, low volume, overextension (RSI above 75, price far above the 20-day average), stop inside normal noise (stop smaller than about half the 5-minute ATR), market regime weak, costs eating the edge (cost in R), thin liquidity, negative or too-few replay results, results/earnings or other event within 3 days, bad news, session timing.

Bear also sets HARD VETOES (any one forces NO-BUY): data guard BAD or missing, results event today or tomorrow, round-trip cost above 25% of the risk, liquidity below the floor, fewer than 20 replay trades, outside the entry window, symbol in a derivatives format (futures/options), a manual flag such as `--flag ASM` or `--flag GSM` (stocks under exchange surveillance, which Claude must check on the web).

### 15. Judge agent (`judge.py`): reads both files and decides
- Verifies both files are fresh (default 10 minutes) and refer to the same plan fingerprint and date.
- Rule: BUY only if bull score is at least 65, bear score is at most 35, the gap (bull minus bear) is at least 25, no hard veto fired, and replay expectancy after costs is at least the configured minimum. Borderline cases return WAIT. Everything else is NO-BUY. All thresholds in config.
- Output: `trader/state/judge.json` with verdict (BUY / WAIT / NO-BUY), scores, conviction label (low/medium/high, never a fake percentage), the top reasons from each side, the vetoes, the plan fingerprint and the time. Print a plain-language explanation.
- Records every decision in `trader/state/judge_log.json`. `judge.py review` compares past decisions with the realized profit and loss from `trader/state/broker.json` and shows how often BUY calls made money after costs, so I can see whether the judge is useful or not.
- Also add `judge.py plan SYMBOL --side buy`: proposes entry, a stop one 5-minute ATR away, a 1.5R target, rounded to the NSE tick of Rs 0.05, and writes `trader/plan.json`.
- Add a new risk gate in `trader-risk/check.py`: `require_judge` (default true). An entry is blocked unless `judge.json` says BUY for the same symbol, date and plan fingerprint, within `judge_max_age_min`. The judge can only add a block. It can never override or relax any existing gate, and a user "yes" never overrides it.
- The judge's output is a rules-based opinion, not a prediction. Say so in the docs and in the printed output.

---

## PART 1B: THE DASHBOARD AGENT (16th agent, `trader-dashboard`)

Build `trader-dashboard/` with `SKILL.md` and `dashboard.py`. It produces a web dashboard in plain HTML, CSS and JavaScript (no frameworks, no build step, no CDN or external requests of any kind). Its job: tell me which trade to choose in the Indian market today, and explain step by step how to follow it. It only displays. It never places an order and has no control that does.

How it runs:
- `python3 trader-dashboard/dashboard.py build` reads every agent's output files (`watchlist.json`, `entry.json`, `plan.json`, `timemachine.json`, `data_guard.json`, `bull.json`, `bear.json`, `judge.json`, `judge_log.json`, `risk.json`, `orders.json`, `prices.json`, `state/broker.json`, `portfolio.json`, news state, config) and writes ONE self-contained file, `trader/dashboard.html`, with the data embedded as JSON, so it opens by double-click (a `file://` page cannot fetch JSON files). Escape the embedded JSON so `</script>` or any text from a headline can never break out of the page.
- `dashboard.py build --watch` rebuilds every 30 seconds while the market is open. `dashboard.py serve` serves the folder on `127.0.0.1` only (never a public address) and the page reloads itself every 30 seconds.
- Missing files are normal. Each panel then says what has not been run yet and which command runs it.

What the page shows (all money in Rs with lakh/crore grouping, all times in IST):
1. **Top bar:** live IST clock, market status (open, closed, holiday with its name, pre-open), time to the entry window, time to the flat-by time, and a large PAPER or LIVE badge. A permanent plain-language banner: "Most intraday traders lose money. This is a rules-based opinion, not a prediction or advice."
2. **Which trade should I choose? (hero card):** ranks today's candidates by the Judge verdict (BUY first, then WAIT, then NO-BUY), then by conviction and net-of-costs expectancy. For the top candidate show: symbol, verdict badge, entry, stop, target, shares, rupees invested, max loss in Rs and as a percentage of the budget, round-trip costs in Rs, reward:risk. If nothing is BUY, show a clear "No trade today is a valid answer" state with the reasons, not a forced pick.
3. **Bull vs Bear:** two opposing score bars (0 to 100) for the selected trade, the top reasons each side gave (with weight and source), the hard vetoes in red, and the Judge's one-paragraph explanation in plain words. Expand any reason to see the numbers behind it.
4. **Candidate table:** every symbol evaluated, sortable, with verdict, bull score, bear score, risk PASS/BLOCK and the first blocking reason.
5. **Step-by-step guide (the main teaching panel):** a checklist driven by the real state files, each step marked done, current, blocked or not started, with a one-line plain explanation, WHY it matters, and the exact command (with a copy button). Steps: 1 check market open and holiday; 2 scan the watchlist; 3 read the news; 4 wait for the entry trigger; 5 data guard OK; 6 exit plan (stop and target); 7 Time Machine; 8 Bull and Bear; 9 Judge; 10 size the position; 11 risk check PASS; 12 the manual order sheet to place in the broker app (BUY as MIS, then SL-M stop and target limit, exact numbers, with a copy button); 13 set alerts for stop, target and flat-by; 14 square off before the flat-by time; 15 record the fill and result so the safety gates and the Judge's review can learn. Only the current step is expanded. A blocked step shows the exact BLOCK message translated into plain words and what to do about it (usually: skip the trade).
6. **Safety panel:** each v3 gate with its current value against its limit (daily, weekly, drawdown, losing-day streak, data freshness, judge freshness) and a progress bar for the live lock (paper days, closed paper trades, profit after costs, profit factor).
7. **Record panel:** paper trading results after costs, equity curve, win rate, and the Judge's review (how often BUY calls made money).
8. **Help panel:** plain-language glossary (R, stop-loss, target, MIS, SL-M, bracket, slippage, STT, square-off, circuit limit, paper trading) and the honest limits of the tool.

Engineering rules for the dashboard:
- Vanilla HTML, CSS, JavaScript. One file out. No external fonts, scripts, images or network calls. Inline SVG for the bars and the equity curve.
- Write text into the page with `textContent` (never `innerHTML` for data) so nothing from a feed can inject code.
- Responsive to phone width with a 16px side gutter and no horizontal page scroll. Light and dark themes through CSS variables, honouring `prefers-color-scheme`, with a manual toggle. Accessible: semantic headings, keyboard focus, sufficient contrast, status never shown by colour alone (always a word or icon too).
- `localStorage` only for small preferences (theme, expanded step), always inside try/catch, and the page works without it.
- Data-driven: all logic that decides step status, ranking and wording lives in plain JavaScript functions that can be unit tested (run them in Node if it is installed, otherwise test the Python builder and the embedded-data contract only).
- Every number shown must come from a state file, never invented. If a number is missing, show "not available" and say which agent produces it.
- No button on the page places, edits or cancels an order. The only actions are copy-to-clipboard for commands and the order sheet, toggling the theme and refreshing.
- Tests: the builder with full state, with partial state, with no state; embedded-JSON escaping (a headline containing `</script><script>alert(1)</script>`); Indian number grouping; ranking order; "no trade" state; step status for each blocked reason; a test that the generated HTML contains no `http://` or `https://` resource loads and no `innerHTML` assignment of data.
- Also render the page once with a headless browser if one is available (Playwright/Chromium) and check it at phone and desktop widths with no console errors, and include the screenshots in the summary.

---

## PART 2: INDIA (NSE, INR, IST) FOR ALL AGENTS

Add a `"market": "IN"` profile (default stays `"US"`) as one shared market-profile definition (hours, timezone, holidays, currency, ticker rules, costs) that every agent uses, instead of a one-off patch in each file. Modules that currently hard-code New York time and `$` (check.py, size.py, ticket.py, exit.py, entry.py, alerts.py, timemachine.py, scanner, news, guard) must read the profile.

Facts to implement (verify the ones marked CHECK before relying on them):
- Hours: 09:15 to 15:30 IST, Monday to Friday. IST is a fixed UTC+05:30 with no daylight saving.
- IMPORTANT BUG TO AVOID: the Indian session runs from 23:45 to 06:00 New York time, so every "today" computed in New York time is the wrong date. Test this explicitly.
- NSE equity holidays 2026 (CHECK against nseindia.com): Jan 15, Jan 26, Mar 3, Mar 26, Mar 31, Apr 3, Apr 14, May 1, May 28, Jun 26, Sep 14, Oct 2, Oct 20, Nov 10, Nov 24, Dec 25. Muhurat session Sunday Nov 8 2026 (times not published at the time of research): treat Sundays as closed. Warn that the list covers 2026 only.
- Symbols: Yahoo uses `.NS` for NSE (for example `RELIANCE.NS`). Allow names with `&` and `-` (M&M, BAJAJ-AUTO). Block derivative formats (futures and options). Equity cash segment only, long only, no F&O.
- Currency: show "Rs" (ASCII, safe on every console).
- Costs (Zerodha equity intraday rates, CHECK): brokerage 0.03% or Rs 20 per executed order, whichever is lower; STT 0.025% on the sell side; NSE transaction charge 0.00307%; GST 18% on brokerage plus transaction plus SEBI charges; SEBI Rs 10 per crore; stamp duty 0.003% on the buy side. Implement `cost_model: "india_intraday"` used by the realized-profit calculation in `check.py`, by the Time Machine and by the Bull/Bear replays. Round-trip cost is roughly 8 to 11 basis points, about three times the US model, so many setups will correctly show no edge.
- Second data source: Stooq does not cover NSE. Add `--second-price` and `--second-source` flags to `guard.py` so Claude can pass a live quote read from the user's broker connector (for example Kite MCP). With `require_second_source` true and no second price, the guard says BAD.
- Order sheet instead of an order tool: there is no Alpaca in India. For `market: IN`, `ticket.py` prints a manual order sheet to place in the broker app: BUY as intraday (MIS), then a stop-loss (SL-M) and a target limit as separate orders (check which order types the broker supports), the max loss in rupees, and the reminder that brokers auto square-off intraday positions around 15:20 and that the user must cancel the other exit order when one fills. Keep the strict one-order-at-a-time "yes" flow and the paper/live flag.
- India config: add `trader-budget/config.india.example.json` with rupee limits for an example budget of Rs 50,000 (state the assumption): risk per trade 0.5%, per day 1%, per week 2%, 2 trades a day, reward:risk of at least 1.5, `no_entries_before` 09:45, `no_entries_after` 14:30, `flat_by` 15:10, `require_judge` true, `require_second_source` true, paper true.

---

## PART 3: PLATFORM AND SETUP GUIDE (write `INDIA.md`)

Plain language, for a beginner. Include, with sources and the date checked:
- Recommendation and reasoning. Findings from research (verify before use):
  - Zerodha: Kite Personal API free (orders, no market data); Kite Connect Rs 500 per month per app with live and historical data (renewal credit from October 2026 if brokerage of at least Rs 2,000 a month). Zerodha's Kite MCP connector for Claude (server URL `https://mcp.kite.trade/mcp`) is mostly read-only: order placement is not available except GTT orders. It is free and useful for portfolio and quote reads, and as the second price source for the guard.
  - Fyers: trading API free, with free market and historical data (per one comparison article, CHECK).
  - Angel One SmartAPI: free (CHECK). Dhan and Upstox: pricing not verified, CHECK before relying on them.
  - SEBI's retail algo framework (phased to April 2026, CHECK the circular): automated orders need an exchange algo ID handled through the broker, retail users supply one or two static IP addresses that the broker whitelists, systems must run in India, and a 10 orders per second threshold applies for registration. A cloud sandbox cannot place orders this way. So recommend this toolkit for signals and paper trading, with orders placed manually in the broker app, at least until the live lock is earned.
- How to open the account (PAN, Aadhaar-linked KYC, bank account, demat and trading account), start with cash equity only, no F&O.
- Step-by-step setup: install, `trader/config.json` from the India example, connect the broker read-only connector, daily routine with exact commands for all 16 agents in order, how to open and read the dashboard, what each BLOCK message means, the paper-trading plan (at least 30 trading days and 50 closed trades before any live trade, and how the live lock enforces it).
- Costs worked example in rupees for a Rs 10,000 and a Rs 1,00,000 trade.
- Tax overview, flagged "check with a Chartered Accountant": intraday equity gains are speculative business income, ITR-3, turnover is the sum of absolute profits and losses, tax audit thresholds depend on turnover and profit, loss carry-forward is four years against speculative income only. Sources disagree on some set-off details, so say so.
- Risk facts with sources: SEBI's study of FY23 found over 70% of individual intraday traders in the equity cash segment lost money (average loss about Rs 5,371), 76% of traders under 30 lost, and 80% of those making more than 500 trades a year lost. State plainly that frequent trading raises the odds of losing.
- A "what this tool cannot do" section: no prediction, no guaranteed stops (stops can fill worse, and a stock can hit a circuit limit), delayed free data, broker outages, auto square-off.

---

## ENGINEERING RULES

- Python 3.8+, standard library only, offline tests (fake the network the way the existing tests do).
- No em dashes in any text file. Keep every SKILL.md at the required structure, including the safety section and the one-order-at-a-time "yes" rule.
- Update `tests/test_repo.py`, `plugin.json`, `marketplace.json` and the README for 16 skills (12 existing plus bull, bear, judge, dashboard). Update the README pipeline diagram and table to show all 16.
- Keep the existing 381 tests passing. Update a test only where behaviour intentionally changes, and say which.
- New tests: evidence scoring for both agents, each hard veto, judge thresholds and WAIT band, freshness and fingerprint mismatch, `require_judge` gate in `check.py`, India calendar and IST date logic (including the New York date trap), India cost model against hand-calculated numbers, derivative symbol block, manual order sheet, `judge.py review`, and India variants for entry, exit, alerts, timemachine, scanner and news.
- Never let any new component place an order, relax a limit, or turn a BLOCK into a PASS.
- At the end: run the full test suite, scan the new code for risky patterns (network calls only to the documented data hosts, no eval/exec/subprocess except the existing pdftotext call in trader-pelosi), zip the project, send the zip plus the key files, and give me a short summary of what changed, which agents are fully India-ready and which are US-only or optional.

## OUTPUT I WANT

1. The updated project zip with all 16 agents, and a sample `trader/dashboard.html` built from fixture data so I can open it right away.
2. The new and changed files individually (`bull.py`, `bear.py`, `judge.py`, `evidence_lib.py`, `dashboard.py`, the changed scripts, `config.india.example.json`, `INDIA.md`).
3. A short summary in plain language: the daily routine across all 16 agents, and an honest statement that the Judge cannot predict the future and that most day traders lose money.
